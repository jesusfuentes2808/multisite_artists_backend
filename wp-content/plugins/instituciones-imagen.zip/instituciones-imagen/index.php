<?php
/**
* Plugin Name: Instituciones imágenes
* Plugin URI: https://www.facebook.com/jesusMFC
* Description: Manejar imágenes de instituciones
* Version: 1.0.0
* Author: Jesus Fuentes
* Author URI: https://www.facebook.com/jesusMFC
*
* Text Domain: wpplugin
* Domain path: /
*/

//Generar HTML
include 'display/table.php';

function sql(){
    global $wpdb;
    $wpdb->prefix= 'wpxu_';

    $select_instituciones = "SELECT DISTINCT wpxu_bp_xprofile_data.value
                        FROM wpxu_users 
                        JOIN wpxu_usermeta 
                        ON wpxu_users.ID = wpxu_usermeta.user_id 
                        JOIN wpxu_bp_xprofile_data
                        ON wpxu_bp_xprofile_data.user_id = wpxu_users.ID
                        WHERE wpxu_usermeta.meta_key = 'wpxu_capabilities' 
                        AND wpxu_usermeta.meta_value LIKE '%miembros%'
                        AND wpxu_bp_xprofile_data.field_id = 1
                        AND wpxu_users.user_status = 0";

    $select_instituciones_result = $wpdb->get_results($select_instituciones);

    foreach ($select_instituciones_result  as $institucion) {
        echo $institucion;
    }

}

add_action('init', 'sql');


